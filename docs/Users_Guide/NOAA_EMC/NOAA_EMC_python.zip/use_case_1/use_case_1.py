"""
Some Descriptive Name Here
==========================

"""

###############################################################################
#
# Some RST for NOAA-EMC 1
#
# .. image:: ../../../../docs/_static/METplus_logo.png
