"""
Verifying GFS gridded precip using stage IV
===========================================

"""

###############################################################################
#
# Some Info for this use case here.
#
# .. image:: ../../../../docs/_static/METplus_logo.png
