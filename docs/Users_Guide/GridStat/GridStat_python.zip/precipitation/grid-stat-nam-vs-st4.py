"""
This is a test
==============

"""

###############################################################################
#
# Some info for this use case here.
#
# .. image:: ../../../../docs/_static/METplus_logo.png
